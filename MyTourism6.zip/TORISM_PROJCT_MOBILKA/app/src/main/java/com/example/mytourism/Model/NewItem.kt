package com.example.mytourism.Model

data class NewsItem(
    var title: String,
    var link: String,
    var description: String,
    var pubDate: String
)