package com.example.mytourism.Model

data class Country(
    val name: String,
    val imageResource: Int

    )