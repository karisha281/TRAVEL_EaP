package com.example.mytourism.Prevalent

import com.example.mytourism.Model.Users

class Prevalent {
    companion object {
        val UserPhoneKey = "UserPhoneKey"
        val UserPasswordKey = "UserPasswordKey"
        val UserName = "UserName"
        var currentOnlineUser: Users? = null
    }

}