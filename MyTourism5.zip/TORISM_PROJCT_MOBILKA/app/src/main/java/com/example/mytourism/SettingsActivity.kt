package com.example.mytourism

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val clickTextProgram = findViewById<TextView>(R.id.for_programm)
        clickTextProgram.setOnClickListener {

            val activityForProgram = Intent(this, ActivityForProgramm::class.java)
            startActivity(activityForProgram)
        }

        val clickTextHelp = findViewById<TextView>(R.id.help)
        clickTextHelp.setOnClickListener {

            val activityForHelp = Intent(this, HelpActivity::class.java)
            startActivity(activityForHelp)
        }

        findViewById<TextView>(R.id.notification).setOnClickListener {
            // Открыть новую активность для управления уведомлениями
            val intent = Intent(this, NotificationActivity::class.java)
            startActivity(intent)
        }

        val changeThemeButton = findViewById<TextView>(R.id.change_theme)
        changeThemeButton.setOnClickListener {
            showThemeSelectionDialog()
        }


    }

    private fun showThemeSelectionDialog() {
        val themes = arrayOf("Темный", "Светлый")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Выберите тему")
            .setItems(themes) { _, which ->
                // Сохранение выбранной темы в SharedPreferences
                val selectedTheme = themes[which]
                saveThemeSelection(selectedTheme)
            }
            .setNegativeButton("Отмена") { dialog, _ ->
                dialog.dismiss()
            }
        builder.show()
    }

    private fun saveThemeSelection(theme: String) {
        sharedPreferences = getSharedPreferences("MyTourismPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("selected_theme", theme)
        editor.apply()

        // Применение выбранной темы
        when (theme) {
            "Темный" -> applyDarkTheme()
            "Светлый" -> applyLightTheme()
        }
    }

    private fun applyDarkTheme() {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)

    }

    private fun applyLightTheme() {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
    }
}