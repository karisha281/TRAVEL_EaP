package com.example.mytourism

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityForProgramm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_for_programm)
    }
}